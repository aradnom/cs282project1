Instructions:

First command argument is the timescale (float), second through fifth are
the X and Y components of first and second object velocity, i.e.
./project1 0.5 100, 25, -100, 25 would guarantee an obect collision.
